<!DOCTYPE html>
<html>
    <head>
        <title>Success Page</title>
        <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap/js/jquery-3.2.1.min.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <link href="index.css" rel="stylesheet" type="text/css">
        <style>
            .adjust{
                margin-top: 80px;
                margin-bottom: 80px;
                font-size: 25px;
            }
        </style>
    </head>
    <body>
        <?php
            include 'include/header.php';
        ?>
        <div class="container adjust">
            <div class="row text-center">
                <div class="col-xs-6 col-xs-offset-3">
                    <h3 align="center">Your order is confirmed. Thank you for shopping with us.</h3><hr>
                    <p align="center">Click <a href="home.php">here</a> to purchase any other item.</p>

                </div>
            </div>
        </div>
        <?php
            include 'include/footer1.php';
        ?>
    </body>
</html>