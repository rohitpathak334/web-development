<footer>
    <div class="navbar-inverse navbar-fixed-bottom">
    <div class="container">
        <table>
            <tr>
                <th>Information</th>
                <th>My Account</th>
                <th>Contact Us</th>
            </tr>
            <tr>
                <td><a href="about.php" style="color: #ddd;">About Us</a></td>
                <td><a href="login.php" style="color: #ddd;">Login</a></td>
                <td>Contact: +91 1230000000</td>
            </tr>
            <tr>
                <td><a href="contact.php" style="color: #ddd;">Contact Us</a></td>
                <td><a href="signup.php" style="color: #ddd;">Signup</a></td>
            </tr>
        </table>
    </div>
    </div>
</footer>